package com.example.demoparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoparserApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoparserApplication.class, args);
	}

}
