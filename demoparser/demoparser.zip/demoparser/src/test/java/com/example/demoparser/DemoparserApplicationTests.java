package com.example.demoparser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoparserApplicationTests {

	@Test
	void contextLoads() {
	}

}
